import React, { useState, useEffect } from "react";

// Suallar və nəticə sxemi
const questions = [
  { q: "Səni daha çox nə idarə edir?", options: ["Hisslərim", "Ağlım", "Hər ikisi, vəziyyətdən asılı"] },
  { q: "Kimsə sənə yalan danışanda nə hiss edirsən?", options: ["Dərhal soyuqlayıram", "Niyə yalan danışdığını anlamğa çalışıram", "Sadəcə susuram, amma yadda saxlayıram"] },
  { q: "Səni insanlarda ən çox nə cəlb edir?", options: ["Dürüstlük və səmimiyyət", "Zəka və düşüncə tərzi", "Enerji və xarizma"] },
  { q: "Problem olanda nə edirsən?", options: ["Tək qalmaq və düşünmək istəyirəm", "Kiminləsə paylaşmaq istəyirəm", "Gülürəm, amma içimdə çox şey gedir"] },
  { q: "İnsanlarla münasibətdə səni ən çox nə yandırır?", options: ["Qiymət verilməmək", "Yanlış anlanmaq", "Ədalətsizlik"] },
  { q: "Qərar verərkən sənə daha çox nə təsir edir?", options: ["Duyğularım", "Məsuliyyət hissim", "İntuisiyam (iç hissim)"] },
  { q: "Keçmişdə səni incidənlər barədə nə düşünürsən?", options: ["Bağışlayıram, amma unutmuram", "Hər kəs öz cəzasını bir gün alır", "Artıq fərq etmir, keçmişdə qaldı"] },
  { q: "Dostların səni necə təsvir edərdi?", options: ["Sakit, amma dərin", "Ağıllı və düşüncəli", "Zarafatcıl, amma ciddi anlarda ciddi"] },
  { q: "Səncə insanı ən çox nə dəyişir?", options: ["Zaman", "Ağrı və təcrübə", "Sevgi"] },
  { q: "Özünü bir sözlə ifadə etsən, nə deyərdin?", options: ["Dəyişkən", "Güclü", "Dərin"] },
];

// Nəticə sxemi (hər cavab variantı üçün tip)
const resultMap = [
  // Hər variantın tipini qeyd edirik (məs: 'emosional', 'rasional', 'qarışıq')
  ["emosional", "rasional", "qarışıq"],
  ["emosional", "rasional", "qarışıq"],
  ["emosional", "rasional", "qarışıq"],
  ["emosional", "rasional", "qarışıq"],
  ["emosional", "rasional", "qarışıq"],
  ["emosional", "rasional", "qarışıq"],
  ["emosional", "rasional", "qarışıq"],
  ["emosional", "rasional", "qarışıq"],
  ["emosional", "rasional", "qarışıq"],
  ["qarışıq", "rasional", "emosional"],
];

// Tipə görə nəticə mətni
const resultText = {
  emosional: {
    title: "Emosional Tip",
    desc: "Sən qərarlarında və münasibətlərində daha çox hisslərinə güvənirsən. Səmimi və empatik insansan. Başqalarının hisslərinə qarşı həssassan."
  },
  rasional: {
    title: "Rasional Tip",
    desc: "Sən hadisələrə və insanlara ağılla yanaşırsan. Analitik və məntiqli düşüncəyə maliksən. Hər zaman soyuqqanlı qalmağa çalışırsan."
  },
  qarışıq: {
    title: "Qarışıq Tip",
    desc: "Sən vəziyyətdən asılı olaraq həm hisslərinə, həm də ağlına güvənirsən. Balanslı və çevik insansan, müxtəlif situasiyalara asan uyğunlaşırsan."
  }
};

function getResult(answers) {
  // Hər tip neçə dəfə seçilib, hesabla
  let counts = { emosional: 0, rasional: 0, qarışıq: 0 };
  answers.forEach((ans, idx) => {
    const idxOption = questions[idx].options.indexOf(ans);
    const type = resultMap[idx][idxOption];
    counts[type]++;
  });
  // Ən çox seçilən tip
  const topType = Object.keys(counts).reduce((a, b) => counts[a] > counts[b] ? a : b);
  return resultText[topType];
}

export default function PersonalityQuizApp() {
  const [current, setCurrent] = useState(0);
  const [answers, setAnswers] = useState([]);
  const [finished, setFinished] = useState(false);
  const [result, setResult] = useState(null);

  // LocalStorage-dan cavabları oxu (refresh olsa da qalsın)
  useEffect(() => {
    const saved = localStorage.getItem("personalityQuizAnswers");
    if (saved) {
      const parsed = JSON.parse(saved);
      setAnswers(parsed);
      setFinished(true);
      setResult(getResult(parsed));
    }
  }, []);

  const handleAnswer = (option) => {
    const newAnswers = [...answers, option];
    setAnswers(newAnswers);
    if (current + 1 < questions.length) {
      setCurrent(current + 1);
    } else {
      setFinished(true);
      setResult(getResult(newAnswers));
      localStorage.setItem("personalityQuizAnswers", JSON.stringify(newAnswers));
    }
  };

  const restartQuiz = () => {
    setCurrent(0);
    setAnswers([]);
    setFinished(false);
    setResult(null);
    localStorage.removeItem("personalityQuizAnswers");
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-fuchsia-500 to-indigo-500 flex flex-col items-center justify-center p-2 sm:p-6">
      <div className="bg-white rounded-2xl shadow-2xl p-4 sm:p-8 w-full max-w-[400px] transition-all">
        <div className="flex flex-col items-center mb-4">
          <img src="https://img.icons8.com/fluency/96/quiz.png" alt="Quiz" className="w-16 h-16 mb-2" />
          <h1 className="text-2xl font-extrabold text-indigo-600 mb-2">Şəxsiyyət Testi</h1>
          <p className="text-sm text-gray-500 text-center mb-2">10 sual ilə özünü kəşf et!</p>
        </div>
        {!finished ? (
          <>
            <div className="animate-fade-in">
              <h2 className="text-xl font-semibold mb-6 text-center text-gray-800">{questions[current].q}</h2>
              <div className="flex flex-col gap-3">
                {questions[current].options.map((opt, idx) => (
                  <button
                    key={idx}
                    onClick={() => handleAnswer(opt)}
                    className="bg-gradient-to-r from-pink-500 to-indigo-500 text-white rounded-xl py-3 font-medium shadow-lg hover:scale-105 active:scale-95 transition-all"
                  >
                    {opt}
                  </button>
                ))}
              </div>
              <div className="flex justify-between items-center mt-6 text-xs text-gray-400">
                <span>Sual {current + 1} / {questions.length}</span>
                <span>Mobil üçün optimallaşdırılıb</span>
              </div>
            </div>
          </>
        ) : (
          <div className="text-center animate-fade-in">
            <h2 className="text-2xl font-extrabold text-indigo-600 mb-2">{result?.title}</h2>
            <p className="mb-4 text-gray-700">{result?.desc}</p>
            <p className="mb-4 text-green-600 font-semibold">Cavablarınız yadda saxlanıldı. 🎉</p>
            <button
              onClick={restartQuiz}
              className="bg-gradient-to-r from-green-400 to-green-600 text-white rounded-full py-2 px-6 font-bold shadow-lg hover:scale-105 transition-all"
            >
              Yenidən Başla
            </button>
          </div>
        )}
      </div>
      <style>{`
        .animate-fade-in {
          animation: fadeIn 0.7s;
        }
        @keyframes fadeIn {
          from { opacity: 0; transform: translateY(24px);}
          to { opacity: 1; transform: translateY(0);}
        }
      `}</style>
    </div>
  );
}